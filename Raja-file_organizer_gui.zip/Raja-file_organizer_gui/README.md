# File Organizer

## Description
This Python script organizes the files in a specified directory (e.g., Downloads) into subfolders by file type.

## Features
- Organizes files into categories: Images, Documents, Videos, and Others
- Supports recursive sorting (optional)
- Dry-run mode to preview changes
- Logging of file operations
- Easily configurable directory path

## Requirements
- Python 3.x

## Usage

1. **Edit the Configuration Section:**
   Modify the `TARGET_DIR`, `RECURSIVE`, and `DRY_RUN` variables at the top of `file_organizer.py`.

2. **Run the Script:**

   ```bash
   python file_organizer.py
